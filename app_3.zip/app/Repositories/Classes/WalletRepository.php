<?php


namespace App\Repositories\Classes;


use App\Repositories\Interfaces\WalletRepositoryInterface;

class WalletRepository implements WalletRepositoryInterface
{

}

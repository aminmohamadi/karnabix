<?php


namespace App\Repositories\Interfaces;


interface OrderNoteRepositoryInterface
{
    public function create(array $data);
}

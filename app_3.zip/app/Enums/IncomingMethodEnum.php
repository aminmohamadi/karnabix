<?php

namespace App\Enums;

use BenSampo\Enum\Enum;


final class IncomingMethodEnum extends Enum
{
    const PERCENT_TYPE = 'percent_type';
}

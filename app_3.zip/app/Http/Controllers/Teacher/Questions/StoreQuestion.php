<?php

namespace App\Http\Controllers\Teacher\Questions;

use Livewire\Component;

class StoreQuestion extends Component
{
    public function render()
    {
        return view('teacher.questions.store-question');
    }
}

<?php

namespace App\Http\Controllers\Teacher\Questions;

use Livewire\Component;

class IndexQuestion extends Component
{
    public function render()
    {
        return view('teacher.questions.index-question');
    }
}

<?php

namespace App\Http\Controllers\Teacher\Transcripts;

use Livewire\Component;

class StoreTranscript extends Component
{
    public function render()
    {
        return view('teacher.transcripts.store-transcript');
    }
}

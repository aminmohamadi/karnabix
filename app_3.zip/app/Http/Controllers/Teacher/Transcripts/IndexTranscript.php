<?php

namespace App\Http\Controllers\Teacher\Transcripts;

use Livewire\Component;

class IndexTranscript extends Component
{
    public function render()
    {
        return view('teacher.transcripts.index-transcript');
    }
}

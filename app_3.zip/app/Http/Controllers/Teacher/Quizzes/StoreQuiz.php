<?php

namespace App\Http\Controllers\Teacher\Quizzes;

use Livewire\Component;

class StoreQuiz extends Component
{
    public function render()
    {
        return view('teacher.quizzes.store-quiz');
    }
}

<?php

namespace App\Http\Controllers\Teacher\Quizzes;

use Livewire\Component;

class IndexQuiz extends Component
{
    public function render()
    {
        return view('teacher.quizzes.index-quiz');
    }
}

<?php

namespace App\Http\Controllers\Teacher\Layouts;

use Livewire\Component;

class Head extends Component
{
    public function render()
    {
        return view('teacher.layouts.head');
    }
}

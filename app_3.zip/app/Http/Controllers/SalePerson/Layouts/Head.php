<?php

namespace App\Http\Controllers\SalePerson\Layouts;

use Livewire\Component;

class Head extends Component
{
    public function render()
    {
        return view('salePerson.layouts.head');
    }
}
